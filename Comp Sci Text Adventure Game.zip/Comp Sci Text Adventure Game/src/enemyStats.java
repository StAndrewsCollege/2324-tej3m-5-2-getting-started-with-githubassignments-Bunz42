public class enemyStats {

    //Set Wild Orange Carrier Stats
    static void orangeStats(){
        Combat.hp = 7; Combat.spd= 6; Combat.bRes = 3; Combat.pRes = 1; Combat.dmg = 6; Combat.kVal = 40;
    }

    //Set Pasta Carrier Stats
    static void pastaStats(){
        Combat.hp = 13; Combat.spd= 5; Combat.bRes = 2; Combat.pRes = 4; Combat.dmg = 7; Combat.kVal = 50;
    }

    //Set Bread Carrier Stats
    static void breadStats(){
        Combat.hp = 10; Combat.spd= 8; Combat.bRes = 1; Combat.pRes = 2; Combat.dmg = 10; Combat.kVal = 50;
    }

    //Set Pickle Carrier Stats
    static void pickleStats(){
        Combat.hp = 15; Combat.spd= 10; Combat.bRes = 0; Combat.pRes = 0; Combat.dmg = 15; Combat.kVal = 60;
    }

    //Set Cookie Carrier Stats
    static void cookieStats(){
        Combat.hp = 20; Combat.spd= 2; Combat.bRes = 3; Combat.pRes = 3; Combat.dmg = 2; Combat.kVal = 60;
    }

    //Set Dango Carrier Stats
    static void dangoStats(){
        Combat.hp = 15; Combat.spd= 7; Combat.bRes = 2; Combat.pRes = 2; Combat.dmg = 10; Combat.kVal = 70;
    }

    //Takes in 5 enemy stats as parameters and prints the enemy's stats.
    static void printEnemyStats(int hp, int spd, int bRes, int pRes, int dmg, int kVal){
        System.out.println("--------------------------------");
        System.out.println("HP: " + hp);
        System.out.println("SPEED: " + spd);
        System.out.println("BITE RESISTANCE: " + bRes);
        System.out.println("PAW RESISTANCE: " + pRes);
        System.out.println("STRENGTH: " + dmg);
        System.out.println("KILL VALUE: " + kVal + " kibble");
        System.out.println("--------------------------------");
    }
}
