import java.util.Random;

public class store {

    static Random rand = new Random();

    //Initializes starting currency at 100
    static int kibble = 100;

    //Initializes the store item pool.
    static String[] store = {"Chocolate -> 10 kibble",
            "Hamburger -> 30 kibble",
            "Gourmet Hamburger -> 50 kibble",
            "Gourmet Dog Food -> 50 kibble",
            "Salted Cabbage -> 20 kibble",
            "Entire Bowl of Noodles -> 80 kibble",
            "Paw Gloves -> 70 kibble",
            "Sharpened Teeth -> 70 kibble",
            "Speedy Paws -> 70 kibble",
            "Hot Pot -> 150 kibble",
            "A5 Wagyu Steak -> 200 kibble"};

    //Randomizes the store by just generating a random index and switching elements to that random index repeatedly to shuffle the array
    static void shuffleStore(String[] s){
        int index = rand.nextInt(s.length);
        for(int i=0; i<s.length; i++){
            String temp = s[i];
            s[i] = s[index];
            s[index] = temp;
        }
    }

    //Prints the store
    static void printStore(){
        System.out.println("--------------------------------------");
        System.out.println("Kibble: " + kibble);
        sp.scrollPrint("The humble merchant corgi has arrived in town!");
        System.out.println("He offers these items: ");
        for (int i=0; i<5; i++){
            System.out.println(store[i]);
        }
        System.out.println("Type /buy to buy an item.");
        System.out.println("--------------------------------------");
    }

}
