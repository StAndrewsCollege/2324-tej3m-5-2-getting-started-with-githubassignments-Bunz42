/* Game Name: Snack Safari with Biscuit: A Canine Culinary Quest
 * Developer: Raymond Hao
 * Description: My game is essentially just a collecting/fighting game. It's a game where the player can continuously enter commands until they win the game.
 * Everytime the player dies, their stats are reset and they can continue playing. There are certain elements of RNG in the game as well as strategy.
 * The overall point of the game is to collect foods, which are obtained through various means. Good Luck!
 * Last Edited: 1/18/2024
 */


import java.util.Arrays;
import java.util.Scanner;

public class Planes {

    //Declares stat variables as static ints
    static int bite, paw, spd, hp, plane;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        printIntro();

        //The user has to type /start to start the game
        if (sc.next().equalsIgnoreCase("/start")) {

            //sets up the game: resets all stats and prints them.
            setup();
            stats.resetStats();
            stats.printStats();

            System.out.println("Type /actions to view all possible actions that Biscuit can perform.");

            //Keeps taking commands from the user until they win the game
            while (Arrays.asList(Collection.collection).contains("🔒")) {

                //makes sure that 50 hp is the maximum hp
                if (stats.hp > 50) stats.hp = 50;

                //Takes a command from the user
                String command = sc.next();

                //Conditional statements that check for each command and perform the corresponding actions
                if (command.equalsIgnoreCase("/actions")) {
                    printActions();
                } else if (command.equalsIgnoreCase("/merchant")) {
                    store.shuffleStore(store.store);
                    store.printStore();
                } else if (command.equalsIgnoreCase("/buy")) {
                    System.out.println("What would you like? Enter an item's name (with no spaces) to purchase an item.");
                    CheckPrice.buy();
                } else if (command.equalsIgnoreCase("/stats")) stats.printStats();
                else if (command.equalsIgnoreCase("/collection")) Collection.printCollection();
                else if (command.equalsIgnoreCase("/search")) Combat.search();
                else System.out.println("Invalid command.");
            }
            printEnding();
        }
    }

    //Assigns starting values to stat variables
    static void setup() {
        bite = 3;
        paw = 2;
        spd = 5;
        hp = 50;
        plane = 0;
    }

    //This prints the bars for the stats
    static void printBars(int rating) {
        for (int i = 0; i < rating; i++) System.out.print("▮");
        System.out.println();
    }

    //This prints all the available actions/commands
    static void printActions() {
        System.out.println("---------------------------------");
        System.out.println("Enter any of these actions to use them at any time outside of combat: ");
        System.out.println("- /actions -> opens up the action list");
        System.out.println("- /merchant -> opens up the store");
        System.out.println("- /buy -> buy an item from the store");
        System.out.println("- /stats -> to view Biscuit's stats");
        System.out.println("- /collection -> to view currently collected foods");
        System.out.println("- /search -> to search for food");
        System.out.println("---------------------------------");
    }

    //This prints the introduction
    static void printIntro() {
        System.out.println("-------------------------------------------------------------------------------------------------------");
        sp.scrollPrint("One day, Biscuit the corgi was fast asleep and dreaming, as she always was, about eating.");
        sp.scrollPrint("She woke up, stretched, and scurried quickly toward her food bowl with her short legs,");
        sp.scrollPrint("ready for her daily meal. However, when she arrived at her bowl, she realized immediately");
        sp.scrollPrint("that it was empty. Her owner had forgotten to feed her! This was unacceptable, and Biscuit");
        sp.scrollPrint("was outraged. She was starving, so she decided it was time to take the matter into her own paws...");
        System.out.println("-------------------------------------------------------------------------------------------------------");

        sp.scrollPrint("In this game, you play as Biscuit the corgi, traversing the lands of her home to find and");
        sp.scrollPrint("collect food. There are elements of luck, skill, and careful thought that will need to be");
        sp.scrollPrint("combined to achieve success. Type /start to begin a run.");
    }

    //This prints the ending after victory: Collecting all foods
    static void printEnding(){
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        sp.scrollPrint("After a long, long journey... Biscuit finally collected all 14 of her favorite foods...");
        Collection.printCollection();
        sp.scrollPrint("She returns home to a nice warm bed, and a loving family with the best owner in the world: Raymond Hao.");
        sp.scrollPrint("Even though Raymond's kind of an idiot for not feeding her, everything's all good in the end!");
        sp.scrollPrint("The game is over, hope you enjoyed... Bye bye! :)");
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        System.exit(0);
    }
}
