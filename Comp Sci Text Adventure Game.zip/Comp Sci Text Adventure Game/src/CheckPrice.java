public class CheckPrice {

    //Buys an item
    static void buy(){
        String item = Planes.sc.next();

        //executes a purchase of chocolate
        if (item.equalsIgnoreCase("chocolate") && store.kibble >= 10) {
            store.kibble -= 10;
            sp.scrollPrint("You just fed chocolate to a dog...");
            sp.delay(2);
            Combat.death();
            Collection.addToCollection("🍫");
        }
        else if (item.equalsIgnoreCase("chocolate") && store.kibble < 10) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of a hamburger
        else if (item.equalsIgnoreCase("hamburger") && store.kibble >= 30) {
            store.kibble -= 30;
            stats.hp += 25;
            sp.scrollPrint("Biscuit eats the burger and recovers 25hp!");
            Collection.addToCollection("🍔");
        }
        else if (item.equalsIgnoreCase("hamburger") && store.kibble < 30) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of a gourmet hamburger
        else if (item.equalsIgnoreCase("gourmethamburger") && store.kibble >= 50) {
            store.kibble -= 50;
            stats.hp += 25;
            stats.bite += 2;
            sp.scrollPrint("Biscuit eats the gourmet burger, recovers 25hp, and gains 2 bite strength!");
            Collection.addToCollection("✨🍔✨");
        }
        else if (item.equalsIgnoreCase("gourmethamburger") && store.kibble < 50) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of gourmet dogfood
        else if (item.equalsIgnoreCase("gourmetdogfood") && store.kibble >= 50) {
            store.kibble -= 50;
            stats.hp += 25;
            stats.paw += 2;
            sp.scrollPrint("Biscuit eats the gourmet dogfood, recovers 25hp, and gains 2 paw strength. Nutritious!");
            Collection.addToCollection("🥫");
        } else if (item.equalsIgnoreCase("gourmetdogfood") && store.kibble < 50) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of salted cabbage
        else if (item.equalsIgnoreCase("saltedcabbage") && store.kibble >= 20) {
            store.kibble -= 20;
            stats.spd += 1;
            sp.scrollPrint("Biscuit eats the salted cabbage and gains 1 speed. Healthy!");
            Collection.addToCollection("🥬");
        } else if (item.equalsIgnoreCase("saltedcabbage") && store.kibble < 20) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of Entire Bowl of Noodles
        else if (item.equalsIgnoreCase("entirebowlofnoodles") && store.kibble >= 80) {
            store.kibble -= 80;
            stats.spd += 2;
            stats.paw += 2;
            stats.bite += 2;
            sp.scrollPrint("Biscuit gobbles the entire bowl of noodles, recovers 30hp and gets +2 to all stats. So filling!");
            Collection.addToCollection("🍜");
        } else if (item.equalsIgnoreCase("entirebowlofnoodles") && store.kibble < 80) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of Paw Gloves
        else if (item.equalsIgnoreCase("pawgloves") && store.kibble >= 70) {
            store.kibble -= 70;
            stats.paw += 3;
            sp.scrollPrint("Biscuit puts on the gloves and feels stronger... +3 paw strength!");
        } else if (item.equalsIgnoreCase("pawgloves") && store.kibble < 70) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of Sharpened Teeth
        else if (item.equalsIgnoreCase("sharpenedteeth") && store.kibble >= 70) {
            store.kibble -= 70;
            stats.bite += 3;
            sp.scrollPrint("Biscuit sharpens her teeth and feels stronger... +3 bite strength!");
        } else if (item.equalsIgnoreCase("sharpenedteeth") && store.kibble < 70) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of Speedy Paws
        else if (item.equalsIgnoreCase("speedypaws") && store.kibble >= 70) {
            store.kibble -= 70;
            stats.spd += 2;
            sp.scrollPrint("Biscuit does some agility exercises and feels faster... +2 speed!");
        } else if (item.equalsIgnoreCase("speedypaws") && store.kibble < 70) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of Hot Pot
        else if (item.equalsIgnoreCase("hotpot") && store.kibble >= 150){
            store.kibble -= 150;
            sp.scrollPrint("Biscuit bought an exquisite, high-class food! The hot pot is nice and steamy...");
            Collection.addToCollection("🥘");
        } else if (item.equalsIgnoreCase("hotpot") && store.kibble < 150) {
            sp.scrollPrint("Not enough kibble.");
        }

        //executes a purchase of A5 Wagyu Steak
        else if (item.equalsIgnoreCase("A5WagyuSteak") && store.kibble >= 200){
            store.kibble -= 200;
            sp.scrollPrint("Biscuit bought an exquisite, high-class food! The steak is tender, flavorful, and cooked medium rare...");
            Collection.addToCollection("🥩");
        } else if (item.equalsIgnoreCase("A5WagyuSteak") && store.kibble < 200) {
            sp.scrollPrint("Not enough kibble.");
        }

        //ensures that if the user enters something that isn't an item name, they will be re-prompted to enter another item
        else sp.scrollPrint("Invalid item.");
    }
}
