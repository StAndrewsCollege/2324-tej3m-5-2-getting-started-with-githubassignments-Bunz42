public class sp {

    //Scroll prints a String of text by turning a string into a char array and printing each char with a delay in between each
    static void scrollPrint(String s){
        char[] chars = s.toCharArray();
        for(int i=0; i<s.length(); i++){
            System.out.print(chars[i]);
            delay(0.01);
        }
        System.out.println();
    }

    //Delay function that uses threading and an exception catch to make the terminal wait a certain number of seconds.
    static void delay(double seconds) {
        try {
            Thread.sleep((int)(seconds*1000));
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
