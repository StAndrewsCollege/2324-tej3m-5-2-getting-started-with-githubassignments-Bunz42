import java.util.Random;

public class Combat {

    //Creates a "Random" object.
    static Random rand = new Random();

    //Creates a String array of enemies
    static String[] enemies = {"Wild Orange Carrier", "Pasta Carrier", "Bread Carrier", "Sour Pickle Carrier",
            "Peanut Butter Cookie Carrier", "Three-Colored Dango Carrier"};

    //Initializes the search success rate
    static int searchSuccess = 10;

    //Searches for an enemy
    static void search() {
        sp.scrollPrint("Biscuit sniffs her surroundings in hopes of finding food... " +
                "Current search success rate: " + searchSuccess + "%");

        //Little dot dot dot animation while searching
        System.out.print("● ");
        sp.delay(0.5);
        System.out.print("● ");
        sp.delay(0.5);
        System.out.print("●");
        sp.delay(0.5);
        System.out.print("\r");
        sp.delay(0.5);

        //Generates a random value between 0 and 99
        int randomValue = rand.nextInt(100);

        boolean enemyFound = false;

        //Executes a for loop where there's a "successRate" chance for the randomValue to equal i.
        for(int i=0; i<searchSuccess; i++){
            if (randomValue == i){
                enemyFound = true;
            }
        }

        //If an enemy is found, reset success rate to 10% generate the enemy and start the fight.
        // If not, make user lose 5hp and increase success rate by 10% for the next search
        if (enemyFound) {
            sp.scrollPrint("Search successful! Biscuit found something!");
            searchSuccess = 10;
            generateEnemy();
            fight();
        } else {
            sp.scrollPrint("Biscuit got tired from searching and lost 5hp...");
            stats.hp -= 5;
            searchSuccess += 10;
            if(stats.hp <= 0) {
                sp.delay(2);
                death();
            }
        }
    }

    //Declares the enemy's stat variables
    static int hp, spd, bRes, pRes, dmg, kVal;

    //Declares randomIndex and Enemy variables as static int and static String respectively.
    static int randomIndex;
    static String enemy;

    //Generates a random enemy from the enemy pool.
    static void generateEnemy() {

        //Generates a random index
        randomIndex = rand.nextInt(6);

        //Assigns a random enemy from the enemy pool to the enemy variable
        enemy = enemies[randomIndex];

        sp.scrollPrint("You encountered a: ");
        Roll.roll(enemies);
        System.out.println(enemy);

        //Generates an enemy based off which index was generated.
        if (randomIndex == 0) {
            enemyStats.orangeStats();
            enemyStats.printEnemyStats(hp, spd, bRes, pRes, dmg, kVal);
        } else if (randomIndex == 1) {
            enemyStats.pastaStats();
            enemyStats.printEnemyStats(hp, spd, bRes, pRes, dmg, kVal);
        } else if (randomIndex == 2) {
            enemyStats.breadStats();
            enemyStats.printEnemyStats(hp, spd, bRes, pRes, dmg, kVal);
        } else if (randomIndex == 3) {
            enemyStats.pickleStats();
            enemyStats.printEnemyStats(hp, spd, bRes, pRes, dmg, kVal);
        } else if (randomIndex == 4) {
            enemyStats.cookieStats();
            enemyStats.printEnemyStats(hp, spd, bRes, pRes, dmg, kVal);
        } else if (randomIndex == 5) {
            enemyStats.dangoStats();
            enemyStats.printEnemyStats(hp, spd, bRes, pRes, dmg, kVal);
        }
    }

    //Prints the available moves
    static void printMoves() {
        sp.scrollPrint("Your move (Type the name of the move you want to use): ");
        System.out.println("- Bite");
        System.out.println("- PawSwipe");
    }

    //Declares damage taken and move variables as static int and String respectively.
    static int dmgTaken;
    static String move = "";

    //This is the fight process
    static void fight() {
        //Executes the first move
        firstMove();
        //Checks if anybody is dead, if yes, return
        if(hp <= 0 || stats.hp <= 0) return;
        //Continuously prompts the user to use a move and also makes the enemy attack back until either the user or enemy dies.
        while (true) {
                move = "";
                printMoves();

                //User moves
                while(!move.equalsIgnoreCase("bite") && !move.equalsIgnoreCase("pawswipe")){
                    move = Planes.sc.next();
                    if (move.equalsIgnoreCase("bite")) {
                        dmgTaken = stats.bite - bRes;
                        if (dmgTaken < 0) dmgTaken = 0;
                        sp.scrollPrint("The " + enemy + " took " + dmgTaken + " damage from the bite!");
                        hp -= dmgTaken;
                    } else if (move.equalsIgnoreCase("pawswipe")) {
                        dmgTaken = stats.paw - pRes;
                        if (dmgTaken < 0) dmgTaken = 0;
                        sp.scrollPrint("The " + enemy + " took " + dmgTaken + " damage from the paw swipe!");
                        hp -= dmgTaken;
                    } else  sp.scrollPrint("Invalid move.");
                }

                //if the enemy dies, increase user currency and add the enemy's corresponding food to the collection. Also break the loop.
                if (hp <= 0) {
                    sp.scrollPrint("Biscuit defeated the " + enemy + "! Biscuit got " + kVal + " kibble!" );
                    addKibbleVal();
                    collectionAdjustment();
                    break;
                }

                //Enemy moves
                sp.scrollPrint("It's the " + enemy + "'s turn...");
                sp.scrollPrint("The " + enemy + " attacks! Biscuit loses " + dmg + " hp!");
                stats.hp -= dmg;

                //if user dies, wait 2 seconds and execute the death function
                if (stats.hp <= 0) {
                    sp.scrollPrint("Biscuit was defeated by the " + enemy + ". Too bad.");
                    sp.delay(2);
                    death();
                    break;
                }
        }
    }

    //Executes the first move of a fight. It's basically the same as the code in the while(true) loop above except it checks for speed to determine who goes first.
    static void firstMove () {
        if (stats.spd > spd) {
            sp.scrollPrint("Biscuit is faster than her opponent, so biscuit goes first!");
            printMoves();
            String move = Planes.sc.next();
            if (move.equalsIgnoreCase("bite")) {
                dmgTaken = stats.bite - bRes;
                if (dmgTaken < 0) dmgTaken = 0;
                sp.scrollPrint("The " + enemy + " took " + dmgTaken + " damage from the bite!");
                hp -= dmgTaken;
            } else if (move.equalsIgnoreCase("pawswipe")) {
                dmgTaken = stats.paw - pRes;
                if (dmgTaken < 0) dmgTaken = 0;
                sp.scrollPrint("The " + enemy + " took " + dmgTaken + " damage from the paw swipe!");
                hp -= dmgTaken;
            } else  sp.scrollPrint("Invalid move.");

            if (hp <= 0) {
                sp.scrollPrint("Biscuit defeated the " + enemy + "! Biscuit got " + kVal + " kibble!" );
                addKibbleVal();
                collectionAdjustment();
            } else {
                sp.scrollPrint("It's the " + enemy + "'s turn...");
                sp.scrollPrint("The " + enemy + " attacks! Biscuit loses " + dmg + " hp!");
                stats.hp -= dmg;
            }
        } else {
            sp.scrollPrint("Biscuit is slower than her opponent, so the " + enemy + " goes first!");
            sp.scrollPrint("The " + enemy + " attacks! Biscuit loses " + dmg + " hp!");
            stats.hp -= dmg;
        }

        if (stats.hp <= 0) {
            sp.scrollPrint("Biscuit was defeated by the " + enemy + ". Too bad.");
            sp.delay(2);
            death();
        }

    }

    //Based on which enemy was defeated, add the corresponding food to the collection
    static void collectionAdjustment(){
        if (randomIndex == 0) {
            Collection.addToCollection("🍊");
        } else if (randomIndex == 1) {
            Collection.addToCollection("🍝");
        } else if (randomIndex == 2) {
            Collection.addToCollection("🍞");
        } else if (randomIndex == 3) {
            Collection.addToCollection("🥒");
        } else if (randomIndex == 4) {
            Collection.addToCollection("🍪");
        } else if (randomIndex == 5) {
            Collection.addToCollection("🍡");
        }
    }

    //Based on the enemy defeated, add the corresponding kill value
    static void addKibbleVal(){
        store.kibble += kVal;
    }

    //If biscuit dies, execute this function and reset all stats and currency.
    static void death(){
        sp.scrollPrint("You killed Biscuit... You're a monster... How could you kill such an innocent dog?");
        sp.scrollPrint("Your stats and kibble have been reset. Keep trying to collect all the foods...");
        Planes.setup();
        stats.resetStats();
    }

}