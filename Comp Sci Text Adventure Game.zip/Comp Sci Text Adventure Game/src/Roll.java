public class Roll {

    //Plays a roll animation for that rolls between the elements in a String array by printing a random element and carriage returning to the beginning of the line.
    //This carriage return will override the line once another thing is written, effectively deleting it. This process is performed repeatedly with a 0.2s delay in between
    static void roll(String[] s){
        for(int i=0; i<20; i++){
            int index = store.rand.nextInt(s.length);
            System.out.print(s[index]);
            System.out.print("\r");
            sp.delay(0.2);
        }
    }
}
