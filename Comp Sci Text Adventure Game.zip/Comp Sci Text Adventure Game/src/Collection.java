public class Collection {

    //Initializes the collection array with every element locked
    static String[] collection = {"🔒", "🔒", "🔒", "🔒", "🔒",
            "🔒", "🔒", "🔒", "🔒", "🔒",
            "🔒", "🔒", "🔒", "🔒"};

    //Prints the collection, separated into two different lines
    static void printCollection(){
        System.out.print("[");
        for(int i=0; i<7; i++) {
            System.out.print(collection[i] + ", ");
        }
        System.out.println();
        for (int i=7; i<14; i++){
            System.out.print(collection[i] + ", ");
        }
        System.out.println("]");
    }

    //Adds an element to the collection. If it's already added, don't add it.
    static void addToCollection(String s){
        for (int i=0; i< collection.length; i++){
            if (collection[i].equals(s)) {
                sp.scrollPrint("You've already collected this food!");
                break;
            }

            if (collection[i].equals("🔒")) {
                sp.scrollPrint(s + " has been added to your collection.");
                collection[i] = s;
                break;
            }
        }
    }
}
