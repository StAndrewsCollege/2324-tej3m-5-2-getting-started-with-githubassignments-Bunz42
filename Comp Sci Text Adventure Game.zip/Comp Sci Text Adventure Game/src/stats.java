public class stats {

    //Declares stat variables
    static int bite, paw, spd, hp;

    //Resets all stats, including currency to 100.
    static void resetStats(){
        bite = Planes.bite; paw = Planes.paw; spd = Planes.spd; hp = Planes.hp; store.kibble = 100;
    }

    //Prints the user's stats with bars.
    static void printStats(){
        System.out.println("--------------------------");
        System.out.println("Biscuit's stats: ");
        System.out.print("Bite Strength: ");
        Planes.printBars(bite);
        System.out.print("Paw Strength: ");
        Planes.printBars(paw);
        System.out.print("Speed: ");
        Planes.printBars(spd);
        System.out.println("HP: " + hp);
        System.out.println("--------------------------");
    }
}
